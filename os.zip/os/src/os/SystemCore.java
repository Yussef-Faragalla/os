package os;

import java.util.ArrayList;
import java.util.Random;
import java.sql.*;

public class SystemCore {

    public static boolean isDeviceEnabled(String device){

    try{
        Connection con = DBConnection.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "SELECT status FROM devices WHERE device_name = ?"
        );

        ps.setString(1, device);

        ResultSet rs = ps.executeQuery();

        if(rs.next()){
            return rs.getInt("status") == 1;
        }

        con.close();

    }catch(Exception e){
        e.printStackTrace();
    }

    return false;
}
    
    public static void toggleDevice(String device){

    try{
        Connection con = DBConnection.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "UPDATE devices SET status = CASE status WHEN 1 THEN 0 ELSE 1 END WHERE device_name = ?"
        );

        ps.setString(1, device);
        ps.executeUpdate();

        con.close();

    }catch(Exception e){
        e.printStackTrace();
    }
}
    public static class Process {
        public int pid;
        public String name;
        public int memory;
        public int cpu;
        public javax.swing.JFrame frame;

       public Process(int pid, String name, int memory, javax.swing.JFrame frame) {
            this.pid = pid;
            this.name = name;
            this.memory = memory;
            this.cpu = 0;
            this.frame = frame;

        }
    }

    public static ArrayList<Process> processes = new ArrayList<>();
    private static int nextPID = 1;

    public static int totalMemory = 8000;
    public static int usedMemory = 0;

public static Process createProcess(String name, javax.swing.JFrame frame) {

    Random rand = new Random();
    int memory = rand.nextInt(400) + 100;

    if (usedMemory + memory > totalMemory) {
        return null;
    }

    Process p = new Process(nextPID++, name, memory, frame);
    processes.add(p);
    usedMemory += memory;

    return p;
}
    

public static boolean killProcess(int pid) {

    for (Process p : processes) {

        if (p.pid == pid) {

            usedMemory -= p.memory;

            if(p.frame != null){
                p.frame.dispose();
            }

            processes.remove(p);
            return true;
        }
    }
    return false;
}


    public static void increaseCPU(int pid, int amount){
        for(Process p : processes){
            if(p.pid == pid){
                p.cpu += amount;
                if(p.cpu > 100)
                    p.cpu = 100;
                break;
            }
        }
    }
       public static void decayCPU(){

    for(Process p : processes){

        if(p.cpu > 0){
            p.cpu -= 1;  
        }

        if(p.cpu < 0){
            p.cpu = 0;
        }
    }
}
    
public static String getProcesses() {

    StringBuilder sb = new StringBuilder();

    for(Process p : processes){
        sb.append("PID: ")
          .append(p.pid)
          .append(" | ")
          .append(p.name)
          .append(" | ")
          .append(p.memory)
          .append(" MB")
          .append(" | CPU: ")
          .append(p.cpu)
          .append("%\n");
    }

    return sb.toString();
}
public static String getMemoryInfo() {
    return "Total: " + totalMemory +
           " MB\nUsed: " + usedMemory +
           " MB\nFree: " + (totalMemory - usedMemory) + " MB";
}
}